package com.techm.ms.resource;

import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.techm.ms.model.User;

import io.restassured.internal.http.Status;
/**
 * 
 *User Resource Implementation
 *
 */
@Controller
@RequestMapping("/user")
public class UserResourceImpl implements UserResource {
	
	ArrayList<User> ar = new ArrayList<User>();
    
	@RequestMapping(value = "create", method = RequestMethod.POST, consumes="application/json", produces="application/json")
    public Response createUser(User user){
    	
    	/*String id = (String)request.getParameter("id");
    	String name = (String)request.getParameter("name");
    	String age = (String)request.getParameter("age");
    	String accountId = (String)request.getParameter("acocuntId");
    	*/
    	if(ar.isEmpty()) {
    		ar.add(user);
    		return Response.status(201).build();
    	}else{
    		if(ar.contains(user)) {
    			return Response.status(409).build();
    		}
    	}
    	return Response.status(500).build();
    }
	
	@RequestMapping(value = "get", method = RequestMethod.GET, consumes="application/json", produces="application/json")
    public Response getUser(@PathParam("name") String name){
    	
    	if(!ar.isEmpty()) {
    		for(int i=0; i<ar.size();i++) {
    			if(name.equals(ar.get(i).getName())){
    				return Response.status(HttpServletResponse.SC_FOUND).entity(ar.get(i)).build();
    			}
    		}
    	}
    	return Response.status(HttpServletResponse.SC_NOT_FOUND).entity("Account with id 123 Not Found").build();
    }
	
}
