package com.techm.ms.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Swagger property configuration.
 */
@Component
@Getter
@Setter
@ConfigurationProperties("swagger-config")
public class SwaggerPropertyConfiguration {
    /**
     *title.
     */
    private String title;
    /**
     *description.
     */
    private String description;
    /**
     *api version.
     */
    private String apiVersion;
    /**
     *terms of service.
     */
    private String termsOfService;
    /**
     * license information about the service.
     */
    private String license;

    /**
     * it returns string representation of the api details.
     * @return api details
     */
    @Override
    public String toString() {
        return "{" +
                "title:'" + title + '\'' +
                ", description:'" + description + '\'' +
                ", apiVersion:'" + apiVersion + '\'' +
                ", termsOfService:'" + termsOfService + '\'' +
                ", license:'" + license + '\'' +
                '}';
    }
}
