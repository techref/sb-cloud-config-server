package com.techm.ms.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import static springfox.documentation.builders.PathSelectors.regex;

/**
 * Swagger configuration implementation for the rest controller paths.
 */
@Configuration
@EnableSwagger2
//@Profile({"dev","uat"})
public class SwaggerConfig {
    /**
     * Logger for configuration.
     */
    static final  Logger logger = LoggerFactory.getLogger(SwaggerConfig.class);

    /**
     * Swagger property configuration.
     */
    @Autowired
    SwaggerPropertyConfiguration swaggerPropertyConfiguration;

    /**
     * Adding docket bean which will construct the swagger content.
     */
    @Bean
    public Docket userApi() {
        return new Docket(DocumentationType.SWAGGER_2).groupName("User")
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.techm.ms.resource"))
                .paths(regex("/user.*"))
                .build()
                .apiInfo(apiInfo());
    }

    /**
     * It builds the api details and returns them.
     * @return api details of the rest services
     */
    private ApiInfo apiInfo() {
        logger.info(swaggerPropertyConfiguration.toString());
        return new ApiInfoBuilder()
                .title(swaggerPropertyConfiguration.getTitle())
                .description(swaggerPropertyConfiguration.getDescription())
                .version(swaggerPropertyConfiguration.getApiVersion())
                .termsOfServiceUrl(swaggerPropertyConfiguration.getTermsOfService())
                .license(swaggerPropertyConfiguration.getLicense())
                .build();
    }


}
